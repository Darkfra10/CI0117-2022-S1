const express = require('express')
var cors = require('cors')
const fs = require('fs')

const app = express()
const port = 3001

const play_file_name = "tetris_play_0.txt"
const state_file_name = "tetris_state.txt"

app.use(express.json());
app.use(express.urlencoded({ extended: true }));
app.use(cors())

app.listen(port, () => {
    console.log(`Tetris api listening on port ${port}`)
  })
  
app.post('/GetPlay', (req, res) => {
    if (req.body.filesPath != undefined && fs.existsSync(req.body.filesPath + "/" + play_file_name)) {
        const data = fs.readFileSync(req.body.filesPath + "/" + play_file_name,
            {encoding:'utf8'});
        console.log(data);
        let play = convertStringToTetrisPlay(data);
        fs.unlinkSync(req.body.filesPath + "/" + play_file_name);
        console.log(play);
        res.send({play: play});
    } else {
        console.log("Get Play. Invalid path or file not found.")
        res.send({ play: undefined });
    }
})

app.post('/SaveState', (req, res) => {
    if (req.body.state != undefined) {
        let fileContent = convertTetrisStateToString(req.body.state);
        fs.writeFileSync(req.body.state.config.filesPath + "/" + state_file_name, fileContent)
        console.log("file written successfully at " + req.body.state.config.filesPath)
        //file written successfully
    } else {
        throw new Error("Invalid state.")
    }
    res.send({ success: "success" });
})

const convertTetrisStateToString = function(state) {
    let result = "";
    result += state.uid + "\n";
    let board = state.board;
    let boardNumRows = board.value.length;
    let boardNumCols = board.value[0].length;  
    result += state.config.numPlaysAhead + "\n";
    result += boardNumRows + "\n";
    result += boardNumCols + "\n";
    for (let i=0; i < boardNumRows; ++i) {
        for (let j=0; j < boardNumCols; ++j) {
            result += board.value[i][j];
        }
        result += "\n";
    }
    result += 7 + "\n";
    for (let k=0; k < 7; ++k) {
        result += state.board.figures[k] + "\n";
    }
    return result;
}

const convertStringToTetrisState = function(stateStr) {
    let lines = stateStr.split('\n');
    let state = {};
    let counter = 0;
    state.uid = parseInt(lines[counter++]);
    state.numPlaysAhead = parseInt(lines[counter++]);
    state.filesPath = lines[counter++];
    let boardNumRows = parseInt(lines[counter++]);
    let boardNumCols = parseInt(lines[counter++]); 
    let board = {};
    board.value = [];

    for (; counter < counter + boardNumRows; ++counter) {
        let row = [];
        for (let j = 0; j < boardNumCols; ++j) {
            row.push(parseInt(line[counter][j]));
        }
        board.value.push(row);
    }

    state.board.figures = [];
    for (let k=0; k < 7; ++k) {
        let figure = {};
        figure.height = lines[counter++];
        figure.width = lines[counter++];
        figure.value = [];
        for (; counter < counter + figure.height; ++counter) {
            let row = [];
            for (let j=0; j < figure.width; ++j) {
                row.push(parseInt(lines[counter][j]));
            }
            figure.value.push(row);
        }
        state.board.figures.push(figure);
    }

    return state;
}

const convertStringToTetrisPlay = function(playStr) {
    /**
        1649009747733    // id
        20               // rows
        10               // cols
        0001111000       // values
        0000330000
        0003300000
        ...
        4417770444
    **/
    let lines = playStr.split('\n');
    console.log("lines:");
    console.log(lines);
    let play = {};
    let counter = 0;
    play.uid = parseInt(lines[counter++]);
    play.figure = lines[counter++][0];
    play.orientation = parseInt(lines[counter++]);
    let boardNumRows = parseInt(lines[counter++]);
    let boardNumCols = parseInt(lines[counter++]); 
    let value = [];
    let max = counter + boardNumRows;
    for (; counter < max; ++counter) {
        let row = [];
        for (let j = 0; j < boardNumCols; ++j) {
            row.push(parseInt(lines[counter][j]));
        }
        value.push(row);
    }
    play.boardValue = value;

    if (counter < lines.length - 1) {
        // Additional misterious value
        play.extraLines = parseInt(lines[counter++]);
    }

    return play;
}


